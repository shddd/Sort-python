#Tri rapide / Quicksort
#Complexité en temps: Au mieux O(n log n), En moyenne O(n log n) Au pire O(n²)
#complexité en espace : En moyenne O(log n), Au pire O(n)
#Entrée : une liste A
#Sortie : A classée dans l'ordre croissant

def trirapide(L):
  